import React from 'react'

const Error404 = () => {
  return (
    <div style={{display: 'flex', justifyContent: 'center'}}>Error404</div>
  )
}

export default Error404